# PictureCombiner
 <h3>图片拼接功能</h3>
 <table>
    <thead>
        <th>拼接方式</th>
        <th>拼接方向</th>
    </thead>
    <tr>
        <td>文件夹拼接:DirCombine</td>
        <td>水平拼接/垂直拼接</td>
    </tr>
    <tr>
        <td>文件拼接:PicCombine</td>
        <td>水平拼接/垂直拼接</td>
    </tr>
 </table>
 <h4>*拼接参数可根据拼接结果进行调整，默认配置在测试中表现尚可，但不保证可应对任意情况*</h4>
 <h4>*重要补充：文件夹拼接默认的多路算法会修改文件夹中的原有图片，如果需要保留原始文件请单独备份或改用单路算法*</h4>
 
 [Github-Address Markdown](https://github.com/yangjinming1062/PictureCombiner/)