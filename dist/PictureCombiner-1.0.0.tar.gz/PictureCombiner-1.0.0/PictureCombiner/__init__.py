name = "PictureCombiner"
from PictureCombiner.PictureCombiner import *